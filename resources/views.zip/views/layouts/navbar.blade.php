<!-- Navbar -->
<nav class="navbar navbar-light bg-warning">
        <div class="container">
            <a class="navbar-brand text-dark" href="/">To Do List</a>
        </div>
</nav>